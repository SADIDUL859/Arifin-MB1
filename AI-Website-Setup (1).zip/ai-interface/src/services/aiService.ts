import { OpenAI } from 'openai';

// Initialize the OpenAI client
const client = new OpenAI({
  baseURL: "https://models.inference.ai.azure.com",
  apiKey: "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", // Using the provided API key
  dangerouslyAllowBrowser: true // Allow API key to be used in browser
});

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export async function sendMessage(messages: ChatMessage[]): Promise<string> {
  try {
    const response = await client.chat.completions.create({
      messages,
      model: "gpt-4o",
      temperature: 1,
      max_tokens: 4096,
      top_p: 1
    });

    return response.choices[0].message.content || "No response";
  } catch (error) {
    console.error('Error calling AI service:', error);
    throw new Error('Failed to get response from AI');
  }
}
