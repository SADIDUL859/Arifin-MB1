import React from 'react';

interface OpenAILogoProps {
  className?: string;
}

const OpenAILogo: React.FC<OpenAILogoProps> = ({ className = "w-6 h-6" }) => {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      fill="none"
    >
      <rect
        width="20"
        height="20"
        rx="4"
        fill="#2D65F0"
        transform="translate(2 2)"
      />
      <path
        d="M12 6.5L17 16.5H7L12 6.5Z"
        fill="white"
      />
      <path
        d="M12 10L9 16H15L12 10Z"
        fill="#2D65F0"
      />
    </svg>
  );
};

export default OpenAILogo;
