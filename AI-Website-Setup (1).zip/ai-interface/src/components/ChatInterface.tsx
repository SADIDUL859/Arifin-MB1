import { useState, FormEvent, useRef, useEffect } from 'react';
import { SendIcon, PaperclipIcon, Mic } from 'lucide-react';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { sendMessage, ChatMessage } from '../services/aiService';
import OpenAILogo from './OpenAILogo';

interface ChatInterfaceProps {
  initialPrompt?: string;
}

export function ChatInterface({ initialPrompt }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: 'system',
      content: 'You are a helpful assistant powered by AI.'
    }
  ]);
  const [userInput, setUserInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messageEndRef = useRef<HTMLDivElement>(null);
  const initialPromptProcessed = useRef(false);

  const scrollToBottom = () => {
    messageEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Process initial prompt if provided
  useEffect(() => {
    if (initialPrompt && !initialPromptProcessed.current) {
      initialPromptProcessed.current = true;
      handleInitialPrompt(initialPrompt);
    }
  }, [initialPrompt]);

  const handleInitialPrompt = async (prompt: string) => {
    const userMessage: ChatMessage = {
      role: 'user',
      content: prompt
    };

    setMessages((prev) => [...prev, userMessage]);
    setIsLoading(true);

    try {
      // Get all messages to maintain conversation context
      const allMessages = [...messages, userMessage];

      // Send message to AI service
      const response = await sendMessage(allMessages);

      // Add AI response to chat
      const assistantMessage: ChatMessage = {
        role: 'assistant',
        content: response
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Error sending message:', error);
      // Add error message to chat
      const errorMessage: ChatMessage = {
        role: 'assistant',
        content: 'Sorry, I encountered an error processing your request. Please try again.'
      };

      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();

    if (!userInput.trim()) return;

    // Add user message to chat
    const userMessage: ChatMessage = {
      role: 'user',
      content: userInput
    };

    setMessages((prev) => [...prev, userMessage]);
    setUserInput('');
    setIsLoading(true);

    try {
      // Get all messages to maintain conversation context
      const allMessages = [...messages, userMessage];

      // Send message to AI service
      const response = await sendMessage(allMessages);

      // Add AI response to chat
      const assistantMessage: ChatMessage = {
        role: 'assistant',
        content: response
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Error sending message:', error);
      // Add error message to chat
      const errorMessage: ChatMessage = {
        role: 'assistant',
        content: 'Sorry, I encountered an error processing your request. Please try again.'
      };

      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-screen">
      {/* Messages section */}
      <div className="flex-grow overflow-auto p-4 space-y-4">
        {messages.filter(msg => msg.role !== 'system').length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center">
            <OpenAILogo className="w-12 h-12 mb-4" />
            <h1 className="text-2xl font-semibold mb-1">How can I help you today?</h1>
          </div>
        ) : (
          messages
            .filter(msg => msg.role !== 'system')
            .map((message, index) => (
              <div key={index} className="max-w-3xl mx-auto w-full">
                <div className="flex items-start gap-2 py-4">
                  {message.role === 'assistant' ? (
                    <div className="flex-shrink-0 w-6 h-6">
                      <OpenAILogo />
                    </div>
                  ) : (
                    <div className="flex-shrink-0 w-6 h-6 bg-gray-300 rounded-full flex items-center justify-center text-gray-800">
                      U
                    </div>
                  )}
                  <div className="whitespace-pre-wrap">{message.content}</div>
                </div>
              </div>
            ))
        )}
        {isLoading && (
          <div className="max-w-3xl mx-auto w-full">
            <div className="flex items-start gap-2 py-4">
              <div className="flex-shrink-0 w-6 h-6">
                <OpenAILogo />
              </div>
              <div className="flex space-x-1 items-center">
                <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse delay-75"></div>
                <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse delay-150"></div>
              </div>
            </div>
          </div>
        )}
        <div ref={messageEndRef} />
      </div>

      {/* Input section */}
      <div className="p-4 border-t border-gray-800 bg-openai-dark">
        <div className="max-w-3xl mx-auto">
          <form onSubmit={handleSubmit} className="flex items-end gap-2">
            <Textarea
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              placeholder="Type your message here..."
              className="min-h-[40px] max-h-[200px] resize-none bg-openai-card border-gray-800 focus-visible:ring-openai-accent"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSubmit(e);
                }
              }}
            />
            <div className="flex gap-2 items-center">
              <Button
                type="button"
                size="icon"
                variant="ghost"
                className="rounded-full text-gray-400 hover:text-white"
                disabled={isLoading}
              >
                <PaperclipIcon className="h-5 w-5" />
              </Button>
              <Button
                type="button"
                size="icon"
                variant="ghost"
                className="rounded-full text-gray-400 hover:text-white"
                disabled={isLoading}
              >
                <Mic className="h-5 w-5" />
              </Button>
              <Button
                type="submit"
                size="icon"
                className="rounded-full bg-openai-accent hover:bg-blue-700"
                disabled={isLoading || !userInput.trim()}
              >
                <SendIcon className="h-4 w-4" />
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
