import { BrainCog } from "lucide-react";

export function Header() {
  return (
    <header className="bg-primary text-primary-foreground w-full py-4 px-6 flex items-center justify-center">
      <div className="flex items-center gap-2">
        <BrainCog size={28} />
        <h1 className="text-2xl font-bold">AI Chat Assistant</h1>
      </div>
    </header>
  );
}
