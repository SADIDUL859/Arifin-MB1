export function Footer() {
  return (
    <footer className="w-full py-2 px-4 text-center text-xs text-gray-500 border-t border-gray-800">
      <div className="flex justify-center items-center gap-2 flex-wrap">
        <span>Azure hosted. AI powered, can make mistakes.</span>
        <a href="#" className="text-blue-400 hover:underline">Share feedback</a>
        <span>Subject to</span>
        <a href="#" className="text-blue-400 hover:underline">Product Terms</a>
        <span>&</span>
        <a href="#" className="text-blue-400 hover:underline">Privacy Statement</a>
        <span>Not intended for production/sensitive data.</span>
      </div>
    </footer>
  );
}
