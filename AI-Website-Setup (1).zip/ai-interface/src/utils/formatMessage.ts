import React from 'react';

/**
 * Formats message text by converting markdown-like syntax to React elements
 * Currently supports:
 * - **bold text**
 */
export function formatMessageText(text: string): React.ReactNode[] {
  if (!text) return [];

  // Split the text by bold markers ** **
  const parts = text.split(/(\*\*.*?\*\*)/g);

  return parts.map((part, index) => {
    // Check if this part is wrapped in bold markers
    if (part.startsWith('**') && part.endsWith('**')) {
      // Extract the text between ** and **
      const boldText = part.slice(2, -2);
      return <strong key={index}>{boldText}</strong>;
    }

    // Return regular text
    return part;
  });
}
