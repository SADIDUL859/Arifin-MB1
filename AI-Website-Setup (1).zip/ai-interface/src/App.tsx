import { useState } from 'react';
import { ArrowRight } from 'lucide-react';
import { Card } from './components/ui/card';
import { ChatInterface } from './components/ChatInterface';
import { Footer } from './components/Footer';
import OpenAILogo from './components/OpenAILogo';

function App() {
  const [chatStarted, setChatStarted] = useState(false);
  const [initialPrompt, setInitialPrompt] = useState<string | undefined>();

  const startChatPrompts = [
    {
      title: "What are some popular tourist attractions in Paris?",
      onClick: () => startChat("What are some popular tourist attractions in Paris?"),
    },
    {
      title: "Can you explain the basics of machine learning?",
      onClick: () => startChat("Can you explain the basics of machine learning?"),
    },
    {
      title: "Can you explain the concept of time dilation in physics?",
      onClick: () => startChat("Can you explain the concept of time dilation in physics?"),
    },
  ];

  const startChat = (prompt?: string) => {
    setInitialPrompt(prompt);
    setChatStarted(true);
  };

  return (
    <div className="dark min-h-screen flex flex-col bg-openai-dark text-openai-text-primary">
      {chatStarted ? (
        <ChatInterface initialPrompt={initialPrompt} />
      ) : (
        <div className="flex-1 flex flex-col items-center justify-center px-4">
          <div className="text-center mb-8 mt-32">
            <OpenAILogo className="w-12 h-12 mx-auto mb-4" />
            <h1 className="text-2xl font-semibold mb-1">OpenAI GPT-4o</h1>
            <p className="text-openai-text-secondary text-sm">
              OpenAI's most advanced multimodal model in the gpt-4o family. Can handle both text and image inputs.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-4xl w-full mt-8">
            {startChatPrompts.map((prompt, index) => (
              <Card
                key={index}
                className="bg-openai-card border border-gray-800 hover:bg-gray-800 transition-colors cursor-pointer p-4 flex flex-col"
                onClick={prompt.onClick}
              >
                <div className="flex-1">
                  <p className="text-sm">{prompt.title}</p>
                </div>
                <div className="flex justify-end mt-2">
                  <ArrowRight size={16} />
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}
      <Footer />
    </div>
  );
}

export default App;
