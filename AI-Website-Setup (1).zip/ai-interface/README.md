# AI Chat Assistant

A modern web application for interacting with AI using the GPT-4o model.

## Features

- Real-time chat interface with AI
- Responsive design that works on mobile and desktop
- Modern UI with dark/light mode support
- Persistent conversation context

## Tech Stack

- React with TypeScript
- Vite for fast development and production builds
- Tailwind CSS for styling
- Shadcn UI components
- OpenAI API integration

## Getting Started

1. Clone this repository
2. Install dependencies: `bun install` or `npm install`
3. Start the development server: `bun run dev` or `npm run dev`
4. Open your browser to http://localhost:3000

## Environment Variables

The API key is currently hardcoded for demo purposes. In a production environment, you should use environment variables:

```
VITE_OPENAI_API_KEY=your_api_key_here
VITE_OPENAI_BASE_URL=https://models.inference.ai.azure.com
```

## Building for Production

```
bun run build
```

This will generate a production-ready build in the `dist` directory.

## License

MIT
